import pygame
import random
import os
from os import path
import sys
import pytmx
from random import randint, uniform
vec = pygame.math.Vector2
MAX_SPEED = 3

health_pot = pygame.image.load(r'C:\Users\usert\Documents\CSF\2022\Spring\Heros Quest\images\Health_Potion.PNG')
hero = pygame.image.load(r'C:\Users\usert\Documents\CSF\2022\Spring\Heros Quest\images\Hero.png')
mummy = pygame.image.load(r'C:\Users\usert\Documents\CSF\2022\Spring\Heros Quest\images\Mummy.png')
snd_dir = path.join(path.dirname(__file__), 'Heros Quest')


WIDTH = 1000
HEIGHT = 800
FPS = 30
# Colours
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (0, 0, 255)  #RGB values from 0-255
RED = (255, 0, 0)
GREEN = (0, 255, 0)
DARKGREY = (40, 40, 40)
LIGHTGREY = (100, 100, 100)
GREY = (128, 128, 128)

BGCOLOR = DARKGREY
TILESIZE = 32
GRIDWIDTH = WIDTH/TILESIZE
GRIDHEIGHT = HEIGHT/TILESIZE

###Player constants
##PLAYER_SPEED = 200
##PLAYER_ROT_SPEED = 250.0
##PLAYER_IMG = 'Hero.png'

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        pygame.sprite.Sprite.__init__(self)
        self.image = hero
        self.image.set_colorkey(GREY)
        self.rect = self.image.get_rect()
        self.rect.center = (WIDTH/2, HEIGHT/2)
        self.current_health = 1000
        self.target_health = 0
        self.max_health = 1000
        self.health_bar_length = 185
        self.health_ratio = self.max_health / self.health_bar_length
        self.health_change_speed = 2
        self.current_direction = 0
        self.rot = 0

    def get_damage(self,amount):
        if self.target_health > 0:
            self.target_health -= amount
        if self.target_health < 0:
            self.target_health = 0

    def get_health(self,amount):
        if self.target_health < self.max_health:
            self.target_health += amount
        if self.target_health > self.max_health:
            self.target_health = self.max_health

    def health_bar(self):
        pygame.draw.rect(WINDOW,(255,0,0),(5, 5,self.target_health / self.health_ratio,17))
        pygame.draw.rect(WINDOW,(255,255,255),(5, 5,self.health_bar_length,17),3)

    def draw_grid(self):
        for x in range(0, WIDTH, TILESIZE):
            pygame.draw.line(WINDOW , LIGHTGREY, (x, 0), (x, HEIGHT))
        for y in range(0, HEIGHT, TILESIZE):
            pygame.draw.line(WINDOW, LIGHTGREY, (0, y), (WIDTH, y))

    def update(self):
        self.rot_speed = 0
        self.vel = vec(0,0)
        keystate = pygame.key.get_pressed()
        prev_center = self.rect.center
        if keystate[pygame.K_a]:
            #self.rot_speed = PLAYER_ROT_SPEED 
            self.rect.centerx += -1.9
        if keystate[pygame.K_d]:
            #self.rot_speed = -PLAYER_ROT_SPEED
            self.rect.centerx += 1.9
        if keystate[pygame.K_s]:
            self.rect.centery += 1.9
        if keystate[pygame.K_w]:
            self.rect.centery += -1.9
            #self.vel = vec(PLAYER_SPEED,0).rotate(-self.rot)   
        self.rect.clamp_ip(pygame.display.get_surface().get_rect())

       
 

class Mob(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self) #,self.groups)
        self.image = mummy
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()
        self.pos = vec(randint(0, WIDTH), randint(0, HEIGHT)) #Represents where sprite is located on the screen, random spawn location
        self.vel = vec(MAX_SPEED, 0).rotate(uniform(0, 360)) #Represents how many pixels the sprite will move in every frame, and in what direction
        self.acc = vec(0,0) #Represents how much the velocity changes in each frame, set to 0,0; so no change in velocity
        self.rect.center = self.pos
        
    def seek_with_approach(self, target): #slows down bad guy to avoid bouncing behavior if he locates hero (target)
        self.desired = (target - self.pos).normalize() * MAX_SPEED
        dist = self.desired.length()
        self.desired.normalize.ip()  #ip() = in place
        if dist < APPROACH_RADIUS:
            self.desired *= dist / APPROACH_RADIUS * MAX_SPEED
        else:
            self.desired *= MAX_SPEED
        steer = (self.desired - self.vel)
        if steer.length() > SEEK_FORCE:
            steer.scale_to_length(SEEK_FORCE)
        return steer
    
    def update(self): #this is the part that tracks the hero
        #find the direction vector (dx, dy) between the bad guy and the player)
        dirvect = vec(player.rect.x - self.rect.x, player.rect.y - self.rect.y)
        if dirvect.magnitude() > 0.0:
            dirvect.normalize()
        #Move along this normalized vector towards the player at the current speed
            dirvect.scale_to_length(MAX_SPEED) # I orginally had  dirvect.scale_to_length(self.speed) but that threw up an error "TypeError: must be real number, not pygame.math.Vector2".  We may have to revisit this again.
        self.rect.move_ip(dirvect)

class Health_Potion(pygame.sprite.Sprite):
    def __init__ (self):
        pygame.sprite.Sprite.__init__(self)
        self.image = health_pot
        self.rect = self.image.get_rect()
        self.pos = vec(randint(0, WIDTH), randint(0, HEIGHT))
        self.rect.center = self.pos

class Map:
    def __init__(self, filename):
        self.data = []
        with open(filename, 'HQ_TileMap_800by600.tmx') as f:
            for line in f:
                self.data.append(line.strip())
        self.tilewidth = len(self.data[0])
        self.tileheight = len(self.data)
        self.width = self.tilewidth * TILESIZE
        self.height = self.tileheight * TILESIZE
        
class TiledMap:
    def __init__(self, filename):
        tm = pytmx.load_pygame(filename, pixelalpha=True)
        self.width = tm.width * tm.tilewidth
        self.height = tm.height * tm.tileheight
        self.tmxdata = tm
        
    def render(self, surface):
        ti = self.tmxdata.get_tile_image_by_gid
        for layer in self.tmxdata.visible_layers:
            if isinstance(layer, pytmx.TiledTileLayer):
                for x, y, gid, in layer:
                    tile = ti(gid)
                    if tile:
                        surface.blit(tile, (x * self.tmxdata.tilewidth,
                                            y * self.tmxdata.tileheight))
                        
    def make_map(self):
        temp_surface = pygame.Surface((self.width, self.height))
        self.render(temp_surface)
        return temp_surface
    
class Game: 
    def __init__(self):  
        self.load_data()
        
    def load_data(self):
        game_folder = path.dirname(__file__)
        map_folder = path.join(game_folder, 'maps')
        self.map = TiledMap(path.join(map_folder, 'HQ_TileMap_800by600.tmx')) 
        self.map_img = self.map.make_map() 
        self.map_rect = self.map_img.get_rect() 

pygame.init() #Initialize pygame sub-system
pygame.mixer.init() #Init pygame sound sub-system
WINDOW = pygame.display.set_mode((WIDTH, HEIGHT)) #Create window on display
pygame.display.set_caption('Hero\'s Quest')
clock = pygame.time.Clock()
player = pygame.sprite.GroupSingle(Player())

##pygame.mixer.music.load(path.join(snd_dir, 'dungeon_1.OGG'))
##pygame.mixer.music.set_volume(0.2)
##pygame.mixer.music.play(loops = -1)
    
#(R, G, B)
#0-255
all_sprites = pygame.sprite.Group()
all_mob = pygame.sprite.Group()
all_pots = pygame.sprite.Group()#I think we can insert a range statement here to spawn more than 1 bad guy
player = Player()
mob = Mob()
hp = Health_Potion()
game = Game()
all_sprites.add(player)
all_mob.add(mob)
all_pots.add(hp)

running = True
while running:
    clock.tick(FPS) #To run at a constant frame rate
    #Process events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            pygame.quit()
            sys.exit()
        health_gain = pygame.sprite.spritecollide(player, all_pots, False, pygame.sprite.collide_circle)
        collision = pygame.sprite.spritecollide(player, all_mob, False, pygame.sprite.collide_circle)
        if health_gain:
            player.get_health(200)
            
                 
    #Update Game State
    all_sprites.update()
    all_mob.update()
    player.update()
    all_pots.update()
    game.update()
    
    #Draw (Render)
    WINDOW.fill(BLACK)
    player.draw_grid()
    player.health_bar()
    all_pots.draw(WINDOW)
    all_sprites.draw(WINDOW)
    all_mob.draw(WINDOW)
    pygame.display.update()
    
pygame.quit()#Clean-up Resources
