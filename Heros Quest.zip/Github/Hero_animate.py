import pygame
from os import path


WIDTH = 500
HEIGHT = 500
WIDTH_PER_IMAGE = 48
HEIGHT_PER_IMAGE = 64
FRAMES_PER_SECOND = 60
ROWS = 7
COLS = 16
INTERVAL = 110
# Color
BLACK = (0, 0, 0)



class SpriteSheet():
    BACKWARD_IMAGES = 0
    FORWARD_IMAGES = 1
    LEFT_IMAGES = 2
    RIGHT_IMAGES = 3
    
    def __init__(self, full_file_name_with_path, rows, columns, width_per_image, height_per_image):
        sprite_sheet = pygame.image.load(full_file_name_with_path)
        self.walk_backward = []
        self.walk_forward = []
        self.walk_left = []
        self.walk_right = []

        image = None
        x = y = 0
        for row in range(rows):
            for column in range(columns):
                if row == 0:
                    image = pygame.Surface((width_per_image, height_per_image))
                    image.blit(sprite_sheet, (0, 0), (x, y, width_per_image, height_per_image))
                    self.walk_backward.append(image)
                elif row == 1:
                    image = pygame.Surface((width_per_image, height_per_image))
                    image.blit(sprite_sheet, (0, 0), (x, y, width_per_image, height_per_image))
                    self.walk_right.append(image)
                elif row == 2:
                    image = pygame.Surface((width_per_image, height_per_image))
                    image.blit(sprite_sheet, (0, 0), (x, y, width_per_image, height_per_image))
                    self.walk_forward.append(image)
                elif row == 3:
                    image = pygame.Surface((width_per_image, height_per_image))
                    image.blit(sprite_sheet, (0, 0), (x, y, width_per_image, height_per_image))
                    self.walk_left.append(image)  
                
                x += width_per_image
                               
            x = 0                 
            y += height_per_image

    def get_images(self, direction):
        if direction == SpriteSheet.BACKWARD_IMAGES:
            return self.walk_backward
        elif direction == SpriteSheet.FORWARD_IMAGES:
            return self.walk_forward
        elif direction == SpriteSheet.RIGHT_IMAGES:
            return self.walk_right
        elif direction == SpriteSheet.LEFT_IMAGES:
            return self.walk_left


class Mummy(pygame.sprite.Sprite):
    LEFT = 0
    RIGHT = 1
    BACK = 2
    FORWARD = 3
    STILL = 4
    
    def __init__(self, sprite_sheet):
        super().__init__()
        self.sprite_sheet = sprite_sheet
        self.image = sprite_sheet.get_images(SpriteSheet.FORWARD_IMAGES)[1]
        self.rect = self.image.get_rect()
        self.direction = Mummy.STILL
        self.last_update = 0
        self.current_index = 1
        self.rect.center = (WIDTH/2, HEIGHT/2)

    def update(self):
        velocity_x = 0
        velocity_y = 0

        keystate = pygame.key.get_pressed()
        if keystate[pygame.K_DOWN]:
            self.direction = Mummy.FORWARD
            velocity_y = 1
        elif keystate[pygame.K_UP]:
            self.direction = Mummy.BACK
            velocity_y = -1
        elif keystate[pygame.K_RIGHT]:
            self.direction = Mummy.RIGHT
            velocity_x = 1
        elif keystate[pygame.K_LEFT]:
            self.direction = Mummy.LEFT
            velocity_x = -1
        else:
            self.direction = Mummy.STILL

        now = pygame.time.get_ticks()

        if self.direction != Mummy.STILL:
            self.rect.centerx += velocity_x
            self.rect.centery += velocity_y
            
            if (now - self.last_update) > INTERVAL:
                self.last_update = now

                if self.direction == Mummy.FORWARD:
                    images = sprite_sheet.get_images(SpriteSheet.FORWARD_IMAGES)
                elif self.direction == Mummy.BACK:
                    images = sprite_sheet.get_images(SpriteSheet.BACKWARD_IMAGES)
                elif self.direction == Mummy.LEFT:
                    images = sprite_sheet.get_images(SpriteSheet.LEFT_IMAGES)
                elif self.direction == Mummy.RIGHT:
                    images = sprite_sheet.get_images(SpriteSheet.RIGHT_IMAGES)

                self.current_index += 1
                self.current_image = images[self.current_index % len(images)]
                self.image = self.current_image
                

pygame.init()
pygame.mixer.init()

clock = pygame.time.Clock()

mummy_sheet = path.join(path.dirname(__file__), 'sorlosheet.png')
sprite_sheet = SpriteSheet(sorlo_super_sheet, ROWS, COLS, WIDTH_PER_IMAGE, HEIGHT_PER_IMAGE)

WINDOW = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption('Mummy Walk!')

all_sprites = pygame.sprite.Group()
mummy = Mummy(sprite_sheet)
all_sprites.add(mummy)

running = True
while running:

    clock.tick(FRAMES_PER_SECOND)

    # Process
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Update
    all_sprites.update()

    # Render
    all_sprites.draw(WINDOW)

    pygame.display.flip()

pygame.quit()
