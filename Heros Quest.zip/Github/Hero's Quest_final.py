import pygame
import random
import os
from os import path
import sys
import pytmx
from random import randint, uniform
import time
#from spritesheet import Spritesheet
vec = pygame.math.Vector2
MAX_SPEED = 2

pygame.init() #Initialize pygame sub-system
##health_pot = pygame.image.load(path.join(path.dirname(__file__), 'Heros Quest', 'Health_Potion.png'))
##hero = pygame.image.load(path.join(path.dirname(__file__), 'Heros Quest', 'Hero.png'))
##snd_dir = path.join(path.dirname(__file__), 'Heros Quest')
##right_blast = pygame.image.load(path.join(path.dirname(__file__), 'Heros Quest', 'hero_blast.png'))
health_pot = pygame.image.load(path.join(path.dirname(__file__), 'Health_Potion.png'))
hero = pygame.image.load(path.join(path.dirname(__file__), 'Hero.png'))
snd_dir = path.join(path.dirname(__file__))
right_blast = pygame.image.load(path.join(path.dirname(__file__), 'hero_blast.png'))
left_blast = pygame.transform.flip(right_blast, True, False)

WIDTH = 1008
HEIGHT = 800
WINDOW = pygame.display.set_mode((WIDTH, HEIGHT)) #Create window on display
FPS = 30
# Colours
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (0, 0, 255)  #RGB values from 0-255
RED = (255, 0, 0)
GREEN = (0, 255, 0)
DARKGREY = (40, 40, 40)
LIGHTGREY = (100, 100, 100)
GREY = (128, 128, 128)
YELLOW = (255, 255, 0)
DIMGREY = (105, 105, 105)
FONT_NAME = 'arial'
TITLE = "HERO'S QUEST!"

WIDTH_PER_IMAGE = 48
HEIGHT_PER_IMAGE = 64
FRAMES_PER_SECOND = 60
ROWS = 4
COLS = 3
INTERVAL = 110
player_size = 20
max_speed = 1
seek_force = 0.1
approach_rad = 50
X_SPEED = 2
Y_SPEED = 2
BLAST_DAMAGE = 10
MOB_KNOCKBACK = 20

BGCOLOR = DARKGREY
TILESIZE = 64
GRIDWIDTH = WIDTH/TILESIZE
GRIDHEIGHT = HEIGHT/TILESIZE

class Camera():
    def __init__(self, width, height):
        self.camera = pygame.Rect(0, 0, width, height)
        self.width = width
        self.height = height

    def apply(self, entity):
        return hero.get_rect()

    def apply_rect(self, rect):
        return rect.move(self.camera.topleft)

    def update(self, target):
        x = -target.rect.centerx + int(WIDTH / 2)
        y = -target.rect.centery + int(HEIGHT / 2)

        # limit scrolling to map size
        x = min(0, x)  # left
        y = min(0, y)  # top
        x = max(-(self.width - WIDTH), x)  # right
        y = max(-(self.height - HEIGHT), y)  # bottom
        self.camera = pygame.Rect(x, y, self.width, self.height)

class SpriteSheet():
    UPWARD_IMAGES = 0
    DOWNWARD_IMAGES = 1
    LEFT_IMAGES = 2
    RIGHT_IMAGES = 3
    STAND_IMAGE = 4
    
    def __init__(self):
        # original format for next 6 lines was X = pygame.image.load(path.join(path.dirname(__file__), 'Heros Quest', 'Hero.png'))
        stand = pygame.image.load(path.join(path.dirname(__file__), 'Hero.png'))
        walk_1 = pygame.image.load(path.join(path.dirname(__file__), 'wizard walk 1.png'))
        walk_2 = pygame.image.load(path.join(path.dirname(__file__), 'wizard walk 2.png'))
        walk_3 = pygame.image.load(path.join(path.dirname(__file__),  'wizard walk 3.png'))
        walk_4 = pygame.image.load(path.join(path.dirname(__file__), 'wizard walk 4.png'))
        shoot = pygame.image.load(path.join(path.dirname(__file__), 'hero_blast.png'))
        stand.set_colorkey(GREY)
        walk_1.set_colorkey(GREY)
        walk_2.set_colorkey(GREY)
        walk_3.set_colorkey(GREY)
        walk_4.set_colorkey(GREY)
        shoot.set_colorkey(GREY)
        self.stand_still = stand
        self.walk_upward = [walk_1, walk_2, walk_3, walk_4]
        self.walk_downward = [walk_1, walk_2, walk_3, walk_4]
        self.walk_left = [pygame.transform.flip(walk_1, True, False), pygame.transform.flip(walk_2, True, False),pygame.transform.flip(walk_3, True, False), pygame.transform.flip(walk_4, True, False)]
        self.walk_right = [walk_1, walk_2, walk_3, walk_4]
        self.blast = [shoot]
        
    def get_images(self, direction):
        if direction == SpriteSheet.UPWARD_IMAGES:
            return self.walk_upward
        elif direction == SpriteSheet.DOWNWARD_IMAGES:
            return self.walk_downward
        elif direction == SpriteSheet.RIGHT_IMAGES:
            return self.walk_right
        elif direction == SpriteSheet.LEFT_IMAGES:
            return self.walk_left
        elif direction == SpriteSheet.STAND_IMAGE:
            return self.stand_still

class SpriteSheet_1():
    DOWN_IMAGES = 0
    UP_IMAGES = 1
    LEFT_IMAGES = 2
    RIGHT_IMAGES = 3
    
    def __init__(self, full_file_name_with_path, rows, columns, width_per_image, height_per_image):
        spritesheet = pygame.image.load(full_file_name_with_path)
        self.walk_upwards = []
        self.walk_downwards = []
        self.walk_left = []
        self.walk_right = []

        image = None
        x = y = 0
        for row in range(rows):
            for column in range(columns):
                if row == 0:
                    image = pygame.Surface((width_per_image, height_per_image))
                    image.blit(spritesheet, (0, 0), (x, y, width_per_image, height_per_image))
                    image.set_colorkey(BLACK)
                    self.walk_upwards.append(image)
                elif row == 1:
                    image = pygame.Surface((width_per_image, height_per_image))
                    image.blit(spritesheet, (0, 0), (x, y, width_per_image, height_per_image))
                    image.set_colorkey(BLACK)
                    self.walk_right.append(image)
                elif row == 2:
                    image = pygame.Surface((width_per_image, height_per_image))
                    image.blit(spritesheet, (0, 0), (x, y, width_per_image, height_per_image))
                    image.set_colorkey(BLACK)
                    self.walk_downwards.append(image)
                elif row == 3:
                    image = pygame.Surface((width_per_image, height_per_image))
                    image.blit(spritesheet, (0, 0), (x, y, width_per_image, height_per_image))
                    image.set_colorkey(BLACK)
                    self.walk_left.append(image)  
                
                x += width_per_image
                               
            x = 0                 
            y += height_per_image

        tmp = self.walk_right[0]
        self.walk_right[0] = self.walk_right[2]
        self.walk_right[2] = tmp
        

    def get_images(self, direction):
        if direction == SpriteSheet_1.UP_IMAGES:
            return self.walk_upwards
        elif direction == SpriteSheet_1.DOWN_IMAGES:
            return self.walk_downwards
        elif direction == SpriteSheet_1.RIGHT_IMAGES:
            return self.walk_right
        elif direction == SpriteSheet_1.LEFT_IMAGES:
            return self.walk_left

class Wizard(pygame.sprite.Sprite):
    LEFT = 0
    RIGHT = 1
    DOWN = 2
    UP = 3
    STAND = 4
    
    def __init__(self, sprite_sheet):
        super().__init__()
        self.sprite_sheet = sprite_sheet
        self.image = sprite_sheet.get_images(SpriteSheet.STAND_IMAGE)
        self.rect = self.image.get_rect()
        self.direction = Wizard.STAND
        self.last_update = 0
        self.current_index = 1
        self.rect.center = (WIDTH/2, HEIGHT/2)
        self.current_health = 1000
        self.target_health = 1000
        self.max_health = 1000
        self.health_bar_length = 185
        self.health_ratio = self.max_health / self.health_bar_length
        self.health_change_speed = 5

    def get_damage(self,amount):
        if self.target_health > 0:
            self.target_health -= amount
        if self.target_health < 0:
            self.target_health = 0

    def get_health(self,amount):
        if self.target_health < self.max_health:
            self.target_health += amount
        if self.target_health > self.max_health:
            self.target_health = self.max_health

    def health_bar(self):
        pygame.draw.rect(WINDOW,(255,0,0),(5, 5,self.target_health / self.health_ratio,17))
        pygame.draw.rect(WINDOW,(255,255,255),(5, 5,self.health_bar_length,17),3)

    def draw_grid(self):
        for x in range(0, WIDTH, TILESIZE):
            pygame.draw.line(WINDOW , LIGHTGREY, (x, 0), (x, HEIGHT))
        for y in range(0, HEIGHT, TILESIZE):
            pygame.draw.line(WINDOW, LIGHTGREY, (0, y), (WIDTH, y))

    def get_pos(self):
        return (self.rect.x, self.rect.y)

    def update(self):
        velocity_x = 0
        velocity_y = 0

        keystate = pygame.key.get_pressed()
        if keystate[pygame.K_s]:
            self.direction = Wizard.DOWN
            velocity_y = 2
        elif keystate[pygame.K_w]:
            self.direction = Wizard.UP
            velocity_y = -2
        elif keystate[pygame.K_d]:
            self.direction = Wizard.RIGHT
            velocity_x = 2
        elif keystate[pygame.K_a]:
            self.direction = Wizard.LEFT
            velocity_x = -2
        else:
            self.direction = Wizard.STAND

        self.rect.clamp_ip(pygame.display.get_surface().get_rect())
            
        now = pygame.time.get_ticks()

        if self.direction != Wizard.STAND:
            self.rect.centerx += velocity_x
            self.rect.centery += velocity_y
            
            if (now - self.last_update) > INTERVAL:
                self.last_update = now

                if self.direction == Wizard.UP:
                    images = sprite_sheet.get_images(SpriteSheet.UPWARD_IMAGES)
                elif self.direction == Wizard.DOWN:
                    images = sprite_sheet.get_images(SpriteSheet.DOWNWARD_IMAGES)
                elif self.direction == Wizard.LEFT:
                    images = sprite_sheet.get_images(SpriteSheet.LEFT_IMAGES)
                elif self.direction == Wizard.RIGHT:
                    images = sprite_sheet.get_images(SpriteSheet.RIGHT_IMAGES)

                self.current_index += 1
                self.current_image = images[self.current_index % len(images)]
                self.image = self.current_image
        else:
            self.image = sprite_sheet.get_images(SpriteSheet.STAND_IMAGE)

        if self.target_health <= 0:
            self.kill()

    def shoot(self):
        blast = None
        
        if self.direction == Wizard.LEFT:
            blast = Blast(self.rect.centerx, self.rect.centery, Blast.LEFT)
        else:
            blast = Blast(self.rect.centerx, self.rect.centery, Blast.RIGHT)
            
        all_sprites.add(blast)
        all_blasts.add(blast)

class Blast(pygame.sprite.Sprite):
    LEFT = -1
    RIGHT = 1

    def __init__(self, x, y, direction):
        pygame.sprite.Sprite.__init__(self)
        self.image = right_blast
        right_blast.set_colorkey(GREY)
        self.rect = self.image.get_rect()
        self.rect.bottom = y + 10
        self.rect.centerx = x + 35
        if direction == Blast.LEFT:
            self.image = left_blast
            self.rect = self.image.get_rect()
            left_blast.set_colorkey(GREY)
            self.rect.bottom = y + 10
            self.rect.centerx = x - 35
            self.speedx = -10
        else:
            self.speedx = 10

    def update(self):
        self.rect.x += self.speedx
        if self.rect.bottom < 0:
            self.kill()

class Mob(pygame.sprite.Sprite):
    LEFT = 0
    RIGHT = 1
    UP = 2
    DOWN = 3
    STILL = 4
    
    def __init__(self, sprite_sheet):
        self.groups = all_sprites
        pygame.sprite.Sprite.__init__(self, self.groups)
        self.image = spritesheet.get_images(SpriteSheet_1.DOWN_IMAGES)[1]
        self.rect = self.image.get_rect()
        self.pos = vec(randint(0, WIDTH), randint(0, HEIGHT))  # position vector
        self.vel = vec(max_speed, 0).rotate(uniform(0, 360))  # velocity vector initially pointing right which rotates.
        self.accel = vec(0, 0)  # acceleration vector. No acceleration acting on player.
        self.rect.center = self.pos
        self.spritesheet = spritesheet
        self.direction = Mob.STILL
        self.last_update = 0
        self.current_index = 1
        self.value = random.uniform(0.5, 1.0)
        self.health = 60

    def follow_hero(self):
        hero_pos = Wizard.get_pos(self)   # determines the hero's position on the window
        # The following line causes acceleration vector's direction to point towards the hero, with a random magnitude:
        self.accel = (hero_pos - self.pos).normalize() * self.value

    def seek_with_approach(self, target):
        self.desired = (target - self.pos)
        dist = self.desired.length() # distance of the mob from the hero
        self.desired.normalize_ip()  # desired velocity to be attained
        if dist < approach_rad:
            self.desired *= dist / approach_rad * self.value  # Within the radius the closer the player gets, the slower they move
        else:
            self.desired *= self.value
        # The following is the steering force vector. It smoothly changes the instantaneous vel to the desired vel
        steer = (self.desired - self.vel)
        if steer.length() > seek_force:
            steer.scale_to_length(seek_force)  # restricts magnitude of steer vector.
        return steer

    def update(self):
        self.accel = self.seek_with_approach(wizard.get_pos())
        # equations of motion:
        self.vel += self.accel  # accelerates velocity every frame.
        
        if self.vel.length() > max_speed:
            self.vel.scale_to_length(max_speed)
            
        self.pos += self.vel  # changes position

        now = pygame.time.get_ticks()

        x, y = self.vel.xy

        if y > 0.0 and abs(y) > abs(x):
            self.direction = Mob.DOWN
        elif y < 0.0 and abs(y) > abs(x):
            self.direction = Mob.UP
        elif x > 0.0 and abs(x) > abs(y):
            self.direction = Mob.RIGHT
        elif x < 0.0 and abs(x) > abs(y):
            self.direction = Mob.LEFT
        else:
            self.direction = Mob.STILL

        if self.direction != Mob.STILL:
            if (now - self.last_update) > INTERVAL:
                self.last_update = now

                if self.direction == Mob.DOWN:
                    images = spritesheet.get_images(SpriteSheet_1.DOWN_IMAGES)
                elif self.direction == Mob.UP:
                    images = spritesheet.get_images(SpriteSheet_1.UP_IMAGES)
                elif self.direction == Mob.LEFT:
                    images = spritesheet.get_images(SpriteSheet_1.LEFT_IMAGES)
                elif self.direction == Mob.RIGHT:
                    images = spritesheet.get_images(SpriteSheet_1.RIGHT_IMAGES)

                self.current_index += 1
                self.current_image = images[self.current_index % len(images)]
                self.image = self.current_image
        if self.health <= 0:
            self.kill()
        
        if self.pos.x > WIDTH:
            self.pos.x = 0
        if self.pos.x < 0:
            self.pos.x = WIDTH
        if self.pos.y > HEIGHT:
            self.pos.y = 0
        if self.pos.y < 0:
            self.pos.y = HEIGHT
            
        self.rect.center = self.pos
        self.rect.clamp_ip(pygame.display.get_surface().get_rect())

    def draw_health(self):
        if self.health > 40:
            col = GREEN
        elif self.health > 20:
            col = YELLOW
        else:
            col = RED
        width = int(self.rect.width) #* self.health / 60)
        health_bar = pygame.Rect(0, 0, width, 5)
        if self.health < 60:
            pygame.draw.rect(self.image, col, health_bar)

##    def take_damage(self, amount):
##        self.health -= amount

class Mummy(pygame.sprite.Sprite):
    LEFT_RIGHT = 0
    UP_DOWN = 1
    DOWN_UP = 2
    
    def __init__(self, sprite_sheet, direction, x, y):
        self.groups = all_sprites
        pygame.sprite.Sprite.__init__(self, self.groups)
        self.image = spritesheet.get_images(SpriteSheet_1.DOWN_IMAGES)[1]
        self.rect = self.image.get_rect()
        self.pos = vec(935, 400)  # position vector
        self.rect.center = self.pos
        self.spritesheet = spritesheet
        self.direction = direction
        self.last_update = 0
        self.current_index = 1
        self.speed = None
        if direction == Mummy.UP_DOWN:
            self.speed = vec(0, -Y_SPEED)
        else:
            self.speed = vec(0, Y_SPEED)
        self.health = 150

    def update(self):            
        self.pos += self.speed  # changes position

        now = pygame.time.get_ticks()

        x, y = self.pos.xy

        if self.speed.x == X_SPEED:
            self.direction = Mob.RIGHT
        elif self.speed.x == -X_SPEED:
            self.direction = Mob.LEFT
        elif self.speed.y == Y_SPEED:
            self.direction = Mob.DOWN
        elif self.speed.y == -Y_SPEED:
            self.direction = Mob.UP
        else:
            self.direction = Mob.STILL

        if self.direction != Mob.STILL:
            if (now - self.last_update) > INTERVAL:
                self.last_update = now

                if self.direction == Mob.DOWN:
                    images = spritesheet.get_images(SpriteSheet_1.DOWN_IMAGES)
                elif self.direction == Mob.UP:
                    images = spritesheet.get_images(SpriteSheet_1.UP_IMAGES)
                    
                elif self.direction == Mob.LEFT:
                    images = spritesheet.get_images(SpriteSheet_1.LEFT_IMAGES)
                elif self.direction == Mob.RIGHT:
                    images = spritesheet.get_images(SpriteSheet_1.RIGHT_IMAGES)

                self.current_index += 1
                self.current_image = images[self.current_index % len(images)]
                self.image = self.current_image
        
##        if self.pos.y > 300:
##            self.speed = vec(-X_SPEED, 0)
##        if self.pos.y < 550:
##            self.speed = vec(X_SPEED, 0)
        if self.pos.y < 250:
            self.speed = vec(0, Y_SPEED)
        if self.pos.y > 550:
            self.speed = vec(0, -Y_SPEED)

        self.rect.center = self.pos
        self.rect.clamp_ip(pygame.display.get_surface().get_rect())

        if self.health <= 0:
            self.kill()

    def draw_health(self):
        if self.health > 100:
            col = GREEN
        elif self.health > 50:
            col = YELLOW
        else:
            col = RED
        width = int(self.rect.width) #* self.health/50)
        health_bar = pygame.Rect(0, 0, width, 5)
        if self.health < 150:
            pygame.draw.rect(self.image, col, health_bar)
        
class Health_Potion(pygame.sprite.Sprite):
    def __init__ (self):
        pygame.sprite.Sprite.__init__(self)
        self.image = health_pot
        health_pot.set_colorkey(WHITE)
        self.rect = self.image.get_rect()
        self.pos = vec(randint(0, WIDTH), randint(0, HEIGHT))
        self.rect.center = self.pos
        self.rect.clamp_ip(pygame.display.get_surface().get_rect())

class Map:
    def __init__(self, filename):
        self.data = []
        with open(filename, 'HQ_TileMap_1008by800.tmx') as f:
            for line in f:
                self.data.append(line.strip())
        self.tilewidth = len(self.data[0])
        self.tileheight = len(self.data)
        self.width = self.tilewidth * TILESIZE
        self.height = self.tileheight * TILESIZE

class Game:
    def __init__(self):
        self.load_data()
        self.font_name = pygame.font.match_font(FONT_NAME)

    def load_data(self):
        game_folder = path.dirname(__file__)
        map_folder = path.join(game_folder, 'maps')
        self.map = TiledMap(path.join(map_folder, 'images', 'HQ_TileMap_1008by800.tmx'))
        self.map_img = self.map.make_map()
        self.map_rect = self.map_img.get_rect()
    
##    def new(self):
##        # start a new game
##        self.score = 0
##        self.all_sprites = pygame.sprite.Group()
##        self.platforms = pygame.sprite.Group()
##        self.player = Player(self)
##        self.all_sprites.add(self.player)
##        for plat in PLATFORM_LIST:
##            p = Platform(*plat)
##            self.all_sprites.add(p)
##            self.platforms.add(p)
##        self.run()
        
    def show_start_screen(self):
        #game splash/start screen
        WINDOW.fill(BGCOLOR)
        #self.screen.blit(background, background_rect) #should keep the game background for our title page, introduction and game over screens
        self.draw_text(TITLE, 60, WHITE, WIDTH / 2, HEIGHT *(2/10))
        self.draw_text("To go up press [W]", 28, WHITE, WIDTH / 2, HEIGHT *(4/10))
        self.draw_text("To go down press [S]", 28, WHITE, WIDTH / 2, HEIGHT *(5/10))
        self.draw_text("To go left press [A]", 28, WHITE, WIDTH / 2, HEIGHT *(6/10))
        self.draw_text("To go right press [D]", 28, WHITE, WIDTH / 2, HEIGHT *(7/10))
        self.draw_text('To shoot, press spacebar', 28, WHITE, WIDTH/2, HEIGHT *(8/10))
        self.draw_text("Press any key to continue", 28, WHITE, WIDTH / 2, HEIGHT * (9/10))
        pygame.display.flip()
        self.wait_for_key()
        
    def show_introduction(self):
        # background into the game
        WINDOW.fill(BGCOLOR)
        #self.screen.blit(background, background_rect) #should keep the game background for our title page, introduction and game over screens
        self.draw_text("What a welcome home!", 24, WHITE, WIDTH / 2, HEIGHT * (1/10))
        self.draw_text("After 5 years of studying at the Wizard Citadel, you have", 24, WHITE, WIDTH / 2, HEIGHT * (2/10))
        self.draw_text("returned home to find evil mummies that have taken over your village.", 24, WHITE, WIDTH / 2, HEIGHT * (3/10))
        self.draw_text("Defeat the evil mummies!", 24, WHITE, WIDTH / 2, HEIGHT *  (5/10))
        #self.draw_text("find the key to unlock the next level.", 18, WHITE, WIDTH / 2, HEIGHT * (5/10))
        self.draw_text("This will free your people!", 24, WHITE, WIDTH / 2, HEIGHT * (6/10))
        self.draw_text("Collect the red potion to restore your health when it runs low.", 24, WHITE, WIDTH / 2, HEIGHT * (7/10))
        self.draw_text("Good luck, brave hero!", 24, WHITE, WIDTH / 2, HEIGHT * (8/10))
        self.draw_text("Press any key to continue", 24, WHITE, WIDTH / 2, HEIGHT * (9/10))
        pygame.display.flip()
        self.wait_for_key()

    def game_over_screen(self):
        # game over/continue
        WINDOW.fill(BGCOLOR)
        #self.screen.blit(background, background_rect)
        self.draw_text("GAME OVER", 48, WHITE, WIDTH / 2, HEIGHT / 4)
        #self.draw_text("Score: " + str(self.score), 22, WHITE, WIDTH / 2, HEIGHT / 2)
        #Ask if they want to play again Y/N
        self.draw_text("Press a key to play again", 22, WHITE, WIDTH / 2, HEIGHT * 3 / 4)
        pygame.display.flip()
        self.wait_for_key()

    def wait_for_key(self):
        waiting = True
        while waiting:
            clock.tick(FPS)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    waiting = False
                    self.running = False
                if event.type == pygame.KEYUP:
                    waiting = False

    def draw_text(self, text, size, color, x, y):
        font = pygame.font.Font(self.font_name, size)
        text_surface = font.render(text, True, color)
        text_rect = text_surface.get_rect()
        text_rect.midtop = (x, y)
        WINDOW.blit(text_surface, text_rect)
        
class TiledMap:
    def __init__(self, filename):
        tm = pytmx.load_pygame(filename, pixelalpha=True)
        self.width = tm.width * tm.tilewidth
        self.height = tm.height * tm.tileheight
        self.tmxdata = tm
        
    def render(self, surface):
        ti = self.tmxdata.get_tile_image_by_gid
        for layer in self.tmxdata.visible_layers:
            if isinstance(layer, pytmx.TiledTileLayer):
                for x, y, gid, in layer:
                    tile = ti(gid)
                    if tile:
                        surface.blit(tile, (x * self.tmxdata.tilewidth,
                                            y * self.tmxdata.tileheight))
                        
    def make_map(self):
        temp_surface = pygame.Surface((self.width, self.height))
        self.render(temp_surface)
        return temp_surface


pygame.mixer.init() #Init pygame sound sub-system
pygame.display.set_caption('Hero\'s Quest')
clock = pygame.time.Clock()

sprite_sheet = SpriteSheet()
mummy_sheet = path.join(path.dirname(__file__), 'Seeking Behaviour', 'assets', 'img', 'mummy-02.png')
spritesheet = SpriteSheet_1(mummy_sheet, ROWS, COLS, WIDTH_PER_IMAGE, HEIGHT_PER_IMAGE)

wizard = pygame.sprite.GroupSingle(Wizard(sprite_sheet))

pygame.mixer.music.load(path.join(snd_dir, 'dungeon_1.OGG'))
pygame.mixer.music.set_volume(0.2)
pygame.mixer.music.play(loops = -1)
    
#(R, G, B)
#0-255
all_sprites = pygame.sprite.Group()
all_mob = pygame.sprite.Group()
all_pots = pygame.sprite.Group()#I think we can insert a range statement here to spawn more than 1 bad guy
all_blasts = pygame.sprite.Group()
wizard = Wizard(sprite_sheet)
mob = Mob(SpriteSheet_1)
mob_1 = Mob(SpriteSheet_1)
mob_2 = Mob(SpriteSheet_1)
mob_3 = Mob(SpriteSheet_1)
mob_4 = Mob(SpriteSheet_1)
mob_5 = Mob(SpriteSheet_1)
mob_6 = Mob(SpriteSheet_1)
guard_mob_1 = Mummy(SpriteSheet_1, Mummy.UP_DOWN, 900, 400)
guard_mob_2 = Mummy(SpriteSheet_1, Mummy.DOWN_UP, 900, 400)
hp = Health_Potion()
game = Game()
camera = Camera(5, 5)
all_sprites.add(wizard)
all_mob.add(mob, mob_1, mob_2, mob_3, mob_4, mob_5, mob_6, guard_mob_1, guard_mob_2)
all_pots.add(hp)
game_over = True

game.show_start_screen()
game.show_introduction()

running = True
while running:
    clock.tick(FPS) #To run at a constant frame rate
    #Process events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                wizard.shoot()
        health_gain = pygame.sprite.spritecollide(wizard, all_pots, False, pygame.sprite.collide_circle)
        blast_collide = pygame.sprite.groupcollide(all_mob, all_blasts, False, pygame.sprite.collide_circle)
        mob_hero_collide = pygame.sprite.spritecollide(wizard, all_mob, False, pygame.sprite.collide_circle)
        if health_gain:
            wizard.get_health(200)
            hp.kill()
        for mob in blast_collide:
            mob.health -= BLAST_DAMAGE
            mob.vel = vec(0, 0)

        if mob_hero_collide:
            wizard.get_damage(5)
            #wizard += vec(MOB_KNOCKBACK, 0).rotate(-mob_hero_collide[0])

        if wizard.target_health <= 0:
            running = False
            pygame.quit()
            sys.exit()
            
##        if:
##            game.game_over_screen()
##            game_over = False

    #Update Game State
    all_sprites.update()
    all_mob.update()
    wizard.update()
    all_pots.update()
    
    #Draw (Render)
    WINDOW.fill(BLACK)
    wizard.draw_grid()
    WINDOW.blit(game.map_img, camera.apply(hero))
    wizard.health_bar()
    all_pots.draw(WINDOW)
    all_sprites.draw(WINDOW)
    all_mob.draw(WINDOW)
    for enemies in all_mob:
        enemies.draw_health()
    pygame.display.update()
    
pygame.quit()#Clean-up Resources

