import pygame 
import random


#SETTINGS
WIDTH = 600
HEIGHT = 800
FPS = 60
FONT_NAME = 'viner_hand_itc'
LIGHTGREY = (211, 211, 211)
DARKGREY = (169, 169, 169)
GREY = (128, 128, 128)
DIMGREY = (105, 105, 105)
WHITE = (255, 255, 255)
BGCOLOR = DIMGREY
TITLE = "HERO'S QUEST!"
#ENSURE background is defined to use lines 47, 60, 78 -> #self.screen.blit(background, background_rect)

#Under Game class
class Game:
    def __init__(self):
        # initialize game window, etc
        pygame.init()
        pygame.mixer.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption(TITLE)
        self.clock = pygame.time.Clock()
        self.running = True
        self.font_name = pygame.font.match_font(FONT_NAME)

    def new(self):
        # start a new game
        self.score = 0
        self.all_sprites = pygame.sprite.Group()
        self.platforms = pygame.sprite.Group()
        self.player = Player(self)
        self.all_sprites.add(self.player)
        for plat in PLATFORM_LIST:
            p = Platform(*plat)
            self.all_sprites.add(p)
            self.platforms.add(p)
        self.run()
        
    def show_start_screen(self):
        #game splash/start screen
        self.screen.fill(BGCOLOR)
        #self.screen.blit(background, background_rect) #should keep the game background for our title page, introduction and game over screens
        self.draw_text(TITLE, 48, WHITE, WIDTH / 2, HEIGHT *(2/10))
        self.draw_text("To go up press [W]", 22, WHITE, WIDTH / 2, HEIGHT *(4/10) )
        self.draw_text("To go down press [S]", 22, WHITE, WIDTH / 2, HEIGHT *(5/10))
        self.draw_text("To go left press [A]", 22, WHITE, WIDTH / 2, HEIGHT *(6/10))
        self.draw_text("To go right press [D]", 22, WHITE, WIDTH / 2, HEIGHT *(7/10))
        self.draw_text("Press any key to continue", 22, WHITE, WIDTH / 2, HEIGHT * (8/10))
        pygame.display.flip()
        self.wait_for_key()

    def show_introduction(self):
        # background into the game
        self.screen.fill(BGCOLOR)
        #self.screen.blit(background, background_rect) #should keep the game background for our title page, introduction and game over screens
        self.draw_text("What a welcome home!", 24, WHITE, WIDTH / 2, HEIGHT * (1/10))
        self.draw_text("After 5 years of studying at the Wizard Citadel, you have", 18, WHITE, WIDTH / 2, HEIGHT * (2/10))
        self.draw_text("returned home to find an evil sorceror has taken over your village.", 18, WHITE, WIDTH / 2, HEIGHT * (3/10))
        self.draw_text("Enter the castle and defeat the evil mob to", 18, WHITE, WIDTH / 2, HEIGHT *  (4/10))
        self.draw_text("find the key to unlock the next level.", 18, WHITE, WIDTH / 2, HEIGHT * (5/10))
        self.draw_text("This will free your people from the sorceror's magic.", 18, WHITE, WIDTH / 2, HEIGHT * (6/10))
        self.draw_text("Collect potions to restore your health when it runs low.", 18, WHITE, WIDTH / 2, HEIGHT * (7/10))
        self.draw_text("Good luck, brave hero!'", 18, WHITE, WIDTH / 2, HEIGHT * (8/10))
        self.draw_text("Press any key to continue", 24, WHITE, WIDTH / 2, HEIGHT * (9/10))
        pygame.display.flip()
        self.wait_for_key()

    def game_over_screen(self):
        # game over/continue
        if not self.running:
            return
        self.screen.fill(BGCOLOR)
        #self.screen.blit(background, background_rect)
        self.draw_text("GAME OVER", 48, WHITE, WIDTH / 2, HEIGHT / 4)
        #self.draw_text("Score: " + str(self.score), 22, WHITE, WIDTH / 2, HEIGHT / 2)
        #Ask if they want to play again Y/N
        self.draw_text("Press a key to play again", 22, WHITE, WIDTH / 2, HEIGHT * 3 / 4)
        pygame.display.flip()
        self.wait_for_key()

    def wait_for_key(self):
        waiting = True
        while waiting:
            self.clock.tick(FPS)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    waiting = False
                    self.running = False
                if event.type == pygame.KEYUP:
                    waiting = False

    def draw_text(self, text, size, color, x, y):
        font = pygame.font.Font(self.font_name, size)
        text_surface = font.render(text, True, color)
        text_rect = text_surface.get_rect()
        text_rect.midtop = (x, y)
        self.screen.blit(text_surface, text_rect)

g = Game() #update g to correct variable for this section
g.show_start_screen()
g.show_introduction()
game_over = True
#game loop
while g.running:
    g.new()
    if game_over:
        g.game_over_screen()
        game_over = False
        #insert all setup for Sprites, mobs, mob blasts, player, player blasts, etc (e.g. all_sprites = pygame.sprite.Group(), player = Player(), etc
        #initialize mob behavior

##if Class Player/self.health <=0:
##        game_over = True
