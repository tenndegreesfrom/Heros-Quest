<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="Locked Door" tilewidth="60" tileheight="60" spacing="10" tilecount="1" columns="1">
 <image source="New Piskel (1) (2).png" width="60" height="60"/>
</tileset>
