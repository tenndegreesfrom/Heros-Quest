<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="Dungeon Tileset 16x16" tilewidth="16" tileheight="16" tilecount="225" columns="15">
 <image source="16x16 dungeon set 1 (1).png" width="250" height="250"/>
</tileset>
