<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="Potions" tilewidth="30" tileheight="32" spacing="2" tilecount="8" columns="4">
 <image source="Potions (1).png" width="128" height="96"/>
</tileset>
