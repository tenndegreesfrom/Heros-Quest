<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="Brown Walls" tilewidth="32" tileheight="32" tilecount="8" columns="8">
 <image source="brick_brown_source (1).png" width="256" height="32"/>
</tileset>
