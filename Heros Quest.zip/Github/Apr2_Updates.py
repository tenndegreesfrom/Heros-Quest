# Mob Blast settings - player hits mob
MOB_BLAST_IMG = 'bullet.png' #Change to blast image or draw a circle
MOB_BLAST_SPEED = 500 #how fast blast travels
MOB_BLAST_LIFETIME = 1000 #how long blast lasts
MOB_BLAST_RATE = 150 #How fast the blasts are produced
#KICKBACK = 200  #Only needed if we want the blast to push the the player back a little (Video #3, 13:24)
MOB_BLAST_SPREAD = 5 #video #3, 14:20 - randomizes blast angle so the blasts don't all come out in a straight line
MOB_BLAST_OFFSET = vec(20, 20) #set to ensure the blasts originate from the right spot on the sprite, will need to adjust based on Sprite
MOB_BLAST_DAMAGE = 10 # How much mob health will decrease by with each hit.


class Mob_blasts(pg.sprite.Sprite):
    def __init__(self, game, pos, dir): #pos, dir are vectors
        self.groups = game.all_sprites, game.mob_blasts
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = game.mob_blast_img #image of the blast, add this to the load_data section of Game class: self.blast_img = pg.image.load(path.join(img_folder, BLAST_IMG)).convert_alpha()  
        #Add to section initializing the variables/setting up for the new game:  self.blast = pg.sprite.Group()
        self.rect = self.image.get_rect()
        self.pos = vec(pos)
        self.rect.center = pos
        spread = uniform(-MOB_BLAST_SPREAD, MOB_BLAST_SPREAD)
        self.vel = dir.rotate(spread) * MOB_BLAST_SPEED
        self.spawn_time = pygame.time.get_ticks()

    def update(self):
        self.pos += self.vel * self.game.dt
        self.rect.center = self.pos
        if pygame.sprite.spritecollideany(self, self.game.walls):  #stops blasts if it hits walls; need to review video on walls
            self.kill()
        if pygame.time.get_ticks() - self.spawn_time > MOB_BLAST_LIFETIME:
            self.kill() # blast gets deleted if it exceeds Blast lifetime



#Using Spacebar to fire blasts
if keystate[pygame.K_SPACE]:
    now = pygame.time.get_ticks()
    if now - self.last_shot> MOB_BLAST_RATE
        self.last_shot = now
        dir = vec(1,0).rotate(-self.rot)
        pos = self.pos + MOB_BLAST_OFFSET.rotate(-self.rot)
        Blast(self.game, pos, dir)

#Update class Player
self.last_shot = 0

#Blasts hits mob - update under Game Class
hits = pygame.sprite.groupcollide(self.mobs, self.mob_blasts, False, True)
for hit in hits:
    hit.health -= MOB_BLAST_DAMAGE #Takes away 10 points from health
    hit.vel = vec(0,0)  #freezes mob in place while being hit

#Mob subclass: new def "draw_health": creates a small health bar over injured mob's head.
def draw_health(self):
    width = int(self.rect.width * self.health / 100)'
    self.health_bar = pygame.Rect(0,0,width, 7)
    if self.health <MOB_HEALTH
        pygame.draw.rect(self.image, RED, self.health_bar)
    
#Class Mob update (def __init__)
self.health =  MOB_HEALTH

#Class Mob update (def update)
if self.health<=0:
    self.kill()

#MOB settings
MOB_HEALTH = 100 #mob takes 10 hits to die

#Draw section of the code
if isinstance(sprite, Mob):
    sprite.draw_health()
self.screen.blit(sprite.image, self.camera.apply(sprite))

#Mob hits player:
#Under Class Game/update
self.all_sprites.update()
self.camera.update(self.player)
hits - pg.sprite.spritecollide(self.player, self.mobs, False, collide_hit_rect)
for hit in hits:
    self.player.health -= PLAYER_BLAST_DAMAGE
    #hit.vel = vec(0,0) #freezes player
    if self.player.health<=0:
        self.playing = False
if hits:
    self.player.pos += vec(PLAYER_KNOCKBACK, 0).rotate(-hits[0].rot)
#NEED TO AVOID GETTING KNOCKED INTO A WALL: VIDEO 10, 13:23


    
#PLAYER_BLAST Settings : need to figure out how to have mob fire at player
PLAYER_BLAST_IMG = 'bullet.png' #Change to blast image or draw a circle
PLAYER_BLAST_SPEED = 300 #how fast blast travels
PLAYER_BLAST_LIFETIME = 500 #how long blast lasts
PLAYER_BLAST_RATE = 75 #How fast the blasts are produced
PLAYER_BLAST_SPREAD = 5 #video #3, 14:20 - randomizes blast angle so the blasts don't all come out in a straight line
PLAYER_BLAST_OFFSET = vec(20, 20) #set to ensure the blasts originate from the right spot on the sprite, will need to adjust based on Sprite
PLAYER_BLAST_DAMAGE = 5 # How much mob health will decrease by with each hit.
PLAYER_KNOCKBACK = 20 #Shifts player "back" a little if hit

class Player_blasts(pg.sprite.Sprite):
    def __init__(self, game, pos, dir): #pos, dir are vectors
        self.groups = game.all_sprites, game.player_blasts
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = game.player_blast_img #image of the blast, add this to the load_data section of Game class: self.blast_img = pg.image.load(path.join(img_folder, BLAST_IMG)).convert_alpha()  
        #Add to section initializing the variables/setting up for the new game:  self.blast = pg.sprite.Group()
        self.rect = self.image.get_rect()
        self.pos = vec(pos)
        self.rect.center = pos
        spread = uniform(-PLAYER_BLAST_SPREAD, PLAYER_BLAST_SPREAD)
        self.vel = dir.rotate(spread) * PLAYER_BLAST_SPEED
        self.spawn_time = pygame.time.get_ticks()

    def update(self):
        self.pos += self.vel * self.game.dt
        self.rect.center = self.pos
        if pygame.sprite.spritecollideany(self, self.game.walls):  #stops blasts if it hits walls; need to review video on walls
            self.kill()
        if pygame.time.get_ticks() - self.spawn_time > PLAYER_BLAST_LIFETIME:
            self.kill() # blast gets deleted if it exceeds Blast lifetime

#Mob Blasts hits player - update under Game Class
hits_player = pygame.sprite.groupcollide(self.player, self.player_blasts, False, True)
for hit_p in hits_player:
    hit_p.health -= PLAYER_BLAST_DAMAGE #Takes away 10 points from player health
    hit_p.vel = vec(0,0)  #freezes player in place while being hit

   
#Class Player/update (def __init__)
self.health =  PLAYER_HEALTH

#Class Player/update (def update)
if self.health<=0:
    self.kill()

#PLAYER settings
PLAYER_HEALTH = 200 #PLAYER takes 20 hits to die

'''TO DO LIST
#Health Potion Spawn - when health bar <= 1/4

#Magic Potion Spawn - when magic bar <= 1/4

#Class Wall - for tile map
'''



    
