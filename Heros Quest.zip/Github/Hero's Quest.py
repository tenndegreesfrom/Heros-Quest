import pygame
import random
import os
from os import path
import sys
import pytmx
from random import randint, uniform
#from spritesheet import Spritesheet
vec = pygame.math.Vector2
MAX_SPEED = 2
MOB_ROT_SPEED = 250
PLAYER_ROT_SPEED = 300

pygame.init() #Initialize pygame sub-system
health_pot = pygame.image.load(r'C:\Users\usert\Documents\CSF\2022\Spring\Heros Quest\Health_Potion.png')
hero = pygame.image.load(r'C:\Users\usert\Documents\CSF\2022\Spring\Heros Quest\Hero.png')
snd_dir = path.join(path.dirname(__file__), 'Heros Quest')
##hero_blast = pygame.image.load(r'C:\Users\usert\Documents\CSF\2022\Spring\Heros Quest\hero_blast.png')

##pygame.init() #Initialize pygame sub-system
##snd_dir = path.join(path.dirname(__file__), 'Heros Quest')
##health_pot = pygame.image.load(path.dirname(__file__), 'Health_Potion.png')
##hero = pygame.image.load(path.dirname(__file__), 'Hero.png')
##hero_blast = pygame.image.load(path.dirname(__file__), 'hero_blast.png')


WIDTH = 800
HEIGHT = 600
WINDOW = pygame.display.set_mode((WIDTH, HEIGHT)) #Create window on display
FPS = 30
# Colours
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (0, 0, 255)  #RGB values from 0-255
RED = (255, 0, 0)
GREEN = (0, 255, 0)
DARKGREY = (40, 40, 40)
LIGHTGREY = (100, 100, 100)
GREY = (128, 128, 128)
YELLOW = (255, 255, 0)
DIMGREY = (105, 105, 105)
BGCOLOR = DIMGREY

TITLE = "HERO'S QUEST!"

WIDTH_PER_IMAGE = 48
HEIGHT_PER_IMAGE = 64
FRAMES_PER_SECOND = 60
ROWS = 4
COLS = 3
INTERVAL = 110
player_size = 30
max_speed = 2
seek_force = 0.1
approach_rad = 150
BULLET_SPEED = 250
BULLET_LIFETIME = 1000
BULLET_RATE = 150
HEALTH_POT_USE = 1

BGCOLOR = DARKGREY
TILESIZE = 32
GRIDWIDTH = WIDTH/TILESIZE
GRIDHEIGHT = HEIGHT/TILESIZE

class Camera():
    def __init__(self, width, height):
        self.camera = pygame.Rect(0, 0, width, height)
        self.width = width
        self.height = height

    def apply(self, entity):
        return hero.get_rect()

    def apply_rect(self, rect):
        return rect.move(self.camera.topleft)

    def update(self, target):
        x = -target.rect.centerx + int(WIDTH / 2)
        y = -target.rect.centery + int(HEIGHT / 2)

        # limit scrolling to map size
        x = min(0, x)  # left
        y = min(0, y)  # top
        x = max(-(self.width - WIDTH), x)  # right
        y = max(-(self.height - HEIGHT), y)  # bottom
        self.camera = pygame.Rect(x, y, self.width, self.height)

class SpriteSheet():
    UPWARD_IMAGES = 0
    DOWNWARD_IMAGES = 1
    LEFT_IMAGES = 2
    RIGHT_IMAGES = 3
    STAND_IMAGE = 4
    
    def __init__(self):
        stand = pygame.image.load(path.join(path.dirname(__file__), 'Heros Quest', 'Hero.png'))
        walk_1 = pygame.image.load(path.join(path.dirname(__file__), 'Heros Quest', 'wizard walk 1.png'))
        walk_2 = pygame.image.load(path.join(path.dirname(__file__), 'Heros Quest', 'wizard walk 2.png'))
        walk_3 = pygame.image.load(path.join(path.dirname(__file__), 'Heros Quest',  'wizard walk 3.png'))
        walk_4 = pygame.image.load(path.join(path.dirname(__file__), 'Heros Quest', 'wizard walk 4.png'))
        stand.set_colorkey(GREY)
        walk_1.set_colorkey(GREY)
        walk_2.set_colorkey(GREY)
        walk_3.set_colorkey(GREY)
        walk_4.set_colorkey(GREY)
        self.stand_still = stand
        self.walk_upward = [walk_1, walk_2, walk_3, walk_4]
        self.walk_downward = [walk_1, walk_2, walk_3, walk_4]
        self.walk_left = [pygame.transform.flip(walk_1, True, False), pygame.transform.flip(walk_2, True, False),pygame.transform.flip(walk_3, True, False), pygame.transform.flip(walk_4, True, False)]
        self.walk_right = [walk_1, walk_2, walk_3, walk_4]
        
    def get_images(self, direction):
        if direction == SpriteSheet.UPWARD_IMAGES:
            return self.walk_upward
        elif direction == SpriteSheet.DOWNWARD_IMAGES:
            return self.walk_downward
        elif direction == SpriteSheet.RIGHT_IMAGES:
            return self.walk_right
        elif direction == SpriteSheet.LEFT_IMAGES:
            return self.walk_left
        elif direction == SpriteSheet.STAND_IMAGE:
            return self.stand_still

class SpriteSheet_1():
    DOWN_IMAGES = 0
    UP_IMAGES = 1
    LEFT_IMAGES = 2
    RIGHT_IMAGES = 3
    
    def __init__(self, full_file_name_with_path, rows, columns, width_per_image, height_per_image):
        spritesheet = pygame.image.load(full_file_name_with_path)
        self.walk_upwards = []
        self.walk_downwards = []
        self.walk_left = []
        self.walk_right = []

        image = None
        x = y = 0
        for row in range(rows):
            for column in range(columns):
                if row == 0:
                    image = pygame.Surface((width_per_image, height_per_image))
                    image.blit(spritesheet, (0, 0), (x, y, width_per_image, height_per_image))
                    self.walk_upwards.append(image)
                elif row == 1:
                    image = pygame.Surface((width_per_image, height_per_image))
                    image.blit(spritesheet, (0, 0), (x, y, width_per_image, height_per_image))
                    self.walk_right.append(image)
                elif row == 2:
                    image = pygame.Surface((width_per_image, height_per_image))
                    image.blit(spritesheet, (0, 0), (x, y, width_per_image, height_per_image))
                    self.walk_downwards.append(image)
                elif row == 3:
                    image = pygame.Surface((width_per_image, height_per_image))
                    image.blit(spritesheet, (0, 0), (x, y, width_per_image, height_per_image))
                    self.walk_left.append(image)  
                
                x += width_per_image
                               
            x = 0                 
            y += height_per_image

        tmp = self.walk_right[0]
        self.walk_right[0] = self.walk_right[2]
        self.walk_right[2] = tmp
        

    def get_images(self, direction):
        if direction == SpriteSheet_1.UP_IMAGES:
            return self.walk_upwards
        elif direction == SpriteSheet_1.DOWN_IMAGES:
            return self.walk_downwards
        elif direction == SpriteSheet_1.RIGHT_IMAGES:
            return self.walk_right
        elif direction == SpriteSheet_1.LEFT_IMAGES:
            return self.walk_left

class Wizard(pygame.sprite.Sprite):
    LEFT = 0
    RIGHT = 1
    DOWN = 2
    UP = 3
    STAND = 4
    
    def __init__(self, sprite_sheet):
        super().__init__()
        self.sprite_sheet = sprite_sheet
        self.image = sprite_sheet.get_images(SpriteSheet.STAND_IMAGE)
        self.rect = self.image.get_rect()
        self.direction = Wizard.STAND
        self.last_update = 0
        self.current_index = 1
        self.rect.center = (WIDTH/2, HEIGHT/2)
        self.current_health = 1000
        self.target_health = 1000
        self.max_health = 1000
        self.health_bar_length = 185
        self.health_ratio = self.max_health / self.health_bar_length
        self.health_change_speed = 2

    def get_damage(self,amount):
        if self.target_health > 0:
            self.target_health -= amount
        if self.target_health < 0:
            self.target_health = 0

    def get_health(self,amount):
        if self.target_health < self.max_health:
            self.target_health += amount
        if self.target_health > self.max_health:
            self.target_health = self.max_health

    def health_bar(self):
        pygame.draw.rect(WINDOW,(255,0,0),(5, 5,self.target_health / self.health_ratio,17))
        pygame.draw.rect(WINDOW,(255,255,255),(5, 5,self.health_bar_length,17),3)

    def draw_grid(self):
        for x in range(0, WIDTH, TILESIZE):
            pygame.draw.line(WINDOW , LIGHTGREY, (x, 0), (x, HEIGHT))
        for y in range(0, HEIGHT, TILESIZE):
            pygame.draw.line(WINDOW, LIGHTGREY, (0, y), (WIDTH, y))

    def update(self):
        velocity_x = 0
        velocity_y = 0

        keystate = pygame.key.get_pressed()
        if keystate[pygame.K_s]:
            self.direction = Wizard.DOWN
            velocity_y = 1
        elif keystate[pygame.K_w]:
            self.direction = Wizard.UP
            velocity_y = -1
        elif keystate[pygame.K_d]:
            self.direction = Wizard.RIGHT
            velocity_x = 1
        elif keystate[pygame.K_a]:
            self.direction = Wizard.LEFT
            velocity_x = -1
        else:
            self.direction = Wizard.STAND
        if keystate[pygame.K_SPACE]:
            now = pygame.time.get_ticks()
            if now - self.last_shot > BULLET_RATE:
                self.last_shot = now
                Bullet(self.game, self.pos, dir)
            

        now = pygame.time.get_ticks()

        if self.direction != Wizard.STAND:
            self.rect.centerx += velocity_x
            self.rect.centery += velocity_y
            
            if (now - self.last_update) > INTERVAL:
                self.last_update = now

                if self.direction == Wizard.UP:
                    images = sprite_sheet.get_images(SpriteSheet.UPWARD_IMAGES)
                elif self.direction == Wizard.DOWN:
                    images = sprite_sheet.get_images(SpriteSheet.DOWNWARD_IMAGES)
                elif self.direction == Wizard.LEFT:
                    images = sprite_sheet.get_images(SpriteSheet.LEFT_IMAGES)
                elif self.direction == Wizard.RIGHT:
                    images = sprite_sheet.get_images(SpriteSheet.RIGHT_IMAGES)

                self.current_index += 1
                self.current_image = images[self.current_index % len(images)]
                self.image = self.current_image
        else:
            self.image = sprite_sheet.get_images(SpriteSheet.STAND_IMAGE)

class Bullet(pygame.sprite.Sprite):
    def __init__(self, game, pos, dir):
        self.groups = all_sprites, bullets
        pygame.sprite.Sprite.__init__(self, self.groups)
        self.image = hero_blast
        hero_blast.set_colorkey(GREY)
        self.rect = self.image.get_rect()
        self.pos = vec(pos)
        self.rect.center = pos
        self.vel = dir.rotate(spread) * BULLET_SPEED
        self.spawn_time = pygame.time.get_ticks()

    def update(self):
        self.pos += self.vel * self.game.dt
        self.rect.center = self.pos
        if pygame.time.get_ticks() - self.spawn_time > BULLET_LIFETIME:
            self.kill()

class Mob(pygame.sprite.Sprite):
    LEFT = 0
    RIGHT = 1
    UP = 2
    DOWN = 3
    STILL = 4
    
    def __init__(self, sprite_sheet):
        self.groups = all_sprites
        pygame.sprite.Sprite.__init__(self, self.groups)
        self.image = spritesheet.get_images(SpriteSheet_1.DOWN_IMAGES)[1]
        self.rect = self.image.get_rect()
        self.pos = vec(randint(0, WIDTH), randint(0, HEIGHT))  # position vector
        self.vel = vec(max_speed, 0).rotate(uniform(0, 360))  # velocity vector initially pointing right which rotates.
        self.accel = vec(0, 0)  # acceleration vector. No acceleration acting on player.
        self.rect.center = self.pos
        self.spritesheet = spritesheet
        self.direction = Mob.STILL
        self.last_update = 0
        self.current_index = 1

    def follow_hero(self):
        hero_pos = sprite_sheet.get_rect()   # determines the hero's position on the window
        # The following line causes acceleration vector's direction to point towards the cursor, with a magnitude of .5:
        self.accel = (hero_pos - self.pos).normalize() * 0.5

    def seek_with_approach(self, target):
        self.desired = (target - self.pos)
        dist = self.desired.length()  # distance of the player from the mouse
        self.desired.normalize_ip()  # desired velocity to be attained
        if dist < approach_rad:
            self.desired *= dist / approach_rad * max_speed  # Within the radius the closer the player gets, the slower they move
        else:
            self.desired *= max_speed
        # The following is the steering force vector. It smoothly changes the instantaneous vel to the desired vel
        steer = (self.desired - self.vel)
        if steer.length() > seek_force:
            steer.scale_to_length(seek_force)  # restricts magnitude of steer vector.
        return steer

    def update(self):
        self.accel = self.seek_with_approach(sprite_sheet.get_rect())
        # equations of motion:
        self.vel += self.accel  # accelerates velocity every frame.
        
        if self.vel.length() > max_speed:
            self.vel.scale_to_length(max_speed)
            
        self.pos += self.vel  # changes position

        now = pygame.time.get_ticks()

        x, y = self.vel.xy

        if y > 0.0 and abs(y) > abs(x):
            self.direction = Mob.DOWN
        elif y < 0.0 and abs(y) > abs(x):
            self.direction = Mob.UP
        elif x > 0.0 and abs(x) > abs(y):
            self.direction = Mob.RIGHT
        elif x < 0.0 and abs(x) > abs(y):
            self.direction = Mob.LEFT
        else:
            self.direction = Mob.STILL

        if self.direction != Mob.STILL:
            if (now - self.last_update) > INTERVAL:
                self.last_update = now

                if self.direction == Mob.DOWN:
                    images = spritesheet.get_images(SpriteSheet_1.DOWN_IMAGES)
                elif self.direction == Mob.UP:
                    images = spritesheet.get_images(SpriteSheet_1.UP_IMAGES)
                elif self.direction == Mob.LEFT:
                    images = spritesheet.get_images(SpriteSheet_1.LEFT_IMAGES)
                elif self.direction == Mob.RIGHT:
                    images = spritesheet.get_images(SpriteSheet_1.RIGHT_IMAGES)

                self.current_index += 1
                self.current_image = images[self.current_index % len(images)]
                self.image = self.current_image
        
        if self.pos.x > WIDTH:
            self.pos.x = 0
        if self.pos.x < 0:
            self.pos.x = WIDTH
        if self.pos.y > HEIGHT:
            self.pos.y = 0
        if self.pos.y < 0:
            self.pos.y = HEIGHT
            
        self.rect.center = self.pos
        

class Health_Potion(pygame.sprite.Sprite):
    def __init__ (self):
        pygame.sprite.Sprite.__init__(self)
        self.image = health_pot
        self.rect = self.image.get_rect()
        self.pos = vec(randint(0, WIDTH), randint(0, HEIGHT))
        self.rect.center = self.pos
        if pygame.sprite.spritecollide(wizard, all_pots, False, pygame.sprite.collide_circle) == HEALTH_POT_USE:
            self.kill()

class Map():
    def __init__(self, filename):
        self.data = []
        with open(filename, 'HQ_TileMap_800by600.tmx') as f:
            for line in f:
                self.data.append(line.strip())
        self.tilewidth = len(self.data[0])
        self.tileheight = len(self.data)
        self.width = self.tilewidth * TILESIZE
        self.height = self.tileheight * TILESIZE

class Game:
    def __init__(self):
        self.load_data()

    def load_data(self):
        game_folder = path.dirname(__file__)
        map_folder = path.join(game_folder, 'maps')
        self.map = TiledMap(path.join(map_folder, 'HQ_TileMap_800by600.tmx'))
        self.map_img = self.map.make_map()
        self.map_rect = self.map_img.get_rect()

    def show_start_screen(self):
        #game splash/start screen
        self.screen.fill(BGCOLOR)
        #self.screen.blit(background, background_rect) #should keep the game background for our title page, introduction and game over screens
        self.draw_text(TITLE, 48, WHITE, WIDTH / 2, HEIGHT *(2/10))
        self.draw_text("To go up press [W]", 22, WHITE, WIDTH / 2, HEIGHT *(4/10) )
        self.draw_text("To go down press [S]", 22, WHITE, WIDTH / 2, HEIGHT *(5/10))
        self.draw_text("To go left press [A]", 22, WHITE, WIDTH / 2, HEIGHT *(6/10))
        self.draw_text("To go right press [D]", 22, WHITE, WIDTH / 2, HEIGHT *(7/10))
        self.draw_text("Press any key to continue", 22, WHITE, WIDTH / 2, HEIGHT * (8/10))
        pygame.display.flip()
        self.wait_for_key()

    def show_introduction(self):
        
class TiledMap(self):
    def __init__(self, filename):
        tm = pytmx.load_pygame(filename, pixelalpha=True)
        self.width = tm.width * tm.tilewidth
        self.height = tm.height * tm.tileheight
        self.tmxdata = tm
        
    def render(self, surface):
        ti = self.tmxdata.get_tile_image_by_gid
        for layer in self.tmxdata.visible_layers:
            if isinstance(layer, pytmx.TiledTileLayer):
                for x, y, gid, in layer:
                    tile = ti(gid)
                    if tile:
                        surface.blit(tile, (x * self.tmxdata.tilewidth,
                                            y * self.tmxdata.tileheight))
                        
    def make_map(self):
        temp_surface = pygame.Surface((self.width, self.height))
        self.render(temp_surface)
        return temp_surface


pygame.mixer.init() #Init pygame sound sub-system
pygame.display.set_caption('Hero\'s Quest')
clock = pygame.time.Clock()

sprite_sheet = SpriteSheet()
mummy_sheet = path.join(path.dirname(__file__), 'Seeking Behaviour', 'assets', 'img', 'mummy-02.png')
spritesheet = SpriteSheet_1(mummy_sheet, ROWS, COLS, WIDTH_PER_IMAGE, HEIGHT_PER_IMAGE)

wizard = pygame.sprite.GroupSingle(Wizard(sprite_sheet))

pygame.mixer.music.load(path.join(snd_dir, 'dungeon_1.OGG'))
pygame.mixer.music.set_volume(0.2)
pygame.mixer.music.play(loops = -1)
    
#(R, G, B)
#0-255
all_sprites = pygame.sprite.Group()
all_mob = pygame.sprite.Group()
all_pots = pygame.sprite.Group()#I think we can insert a range statement here to spawn more than 1 bad guy
wizard = Wizard(sprite_sheet)
mob = Mob(SpriteSheet_1)
hp = Health_Potion()
game = Game()
camera = Camera(5, 5)
all_sprites.add(wizard)
all_mob.add(mob)
all_pots.add(hp)

running = True
while running:
    clock.tick(FPS) #To run at a constant frame rate
    #Process events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            pygame.quit()
            sys.exit()
        health_gain = pygame.sprite.spritecollide(wizard, all_pots, False, pygame.sprite.collide_circle)
        if health_gain:
            wizard.get_health(200)

                 
    #Update Game State
    all_sprites.update()
    all_mob.update()
    wizard.update()
    all_pots.update()
    
    #Draw (Render)
    WINDOW.fill(BLACK)
    WINDOW.blit(game.map_img, camera.apply(hero))
    wizard.draw_grid()
    wizard.health_bar()
    all_pots.draw(WINDOW)
    all_sprites.draw(WINDOW)
    all_mob.draw(WINDOW)
    pygame.display.update()
    
pygame.quit()#Clean-up Resources

